#!/bin/bash
#set -e

#!/bin/bash
#set -e

path="$(pwd)/g/"
testfiles=$(ls $path)
flag=0
for element in $testfiles
do
export ASAN_OPTIONS=allocator_may_return_null=1:detect_leaks=0:halt_on_error=0
  if [[ flag -lt $1 ]]; then
    echo $path$element
    ../autotrace $path$element &> /dev/null
  else
    break
  fi
  let flag++
done